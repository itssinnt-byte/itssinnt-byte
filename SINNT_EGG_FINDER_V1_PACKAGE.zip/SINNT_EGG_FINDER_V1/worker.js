/**
 * SINNT EGG FINDER V1 - Cloudflare Worker + D1
 * No Roblox password, cookie, account ID, or executor telemetry is collected.
 * POST sightings is allowed ONLY with configured REPORTER_KEY secret.
 * Reader endpoint is public. Reports are untrusted and may be inaccurate.
 */
const TTL_SECONDS = 100;
const MAX_EGGS_PER_REPORT = 60;
const MAX_BODY_BYTES = 35000;
const JOB_ID_RE = /^[A-Za-z0-9_-]{8,96}$/;
const headers = {
  'content-type': 'application/json; charset=utf-8',
  'access-control-allow-origin': '*',
  'access-control-allow-methods': 'GET, POST, OPTIONS',
  'access-control-allow-headers': 'Content-Type, Authorization',
  'cache-control': 'no-store'
};
function json(data, code=200) {
  return new Response(JSON.stringify(data), { status: code, headers });
}
function cleanText(value, len=70) {
  if (typeof value !== 'string' && typeof value !== 'number') return '';
  return String(value).replace(/[\u0000-\u001f\u007f]/g,'').slice(0,len).trim();
}
function cleanNumber(v) {
  const n = Number(v);
  return (v !== null && v !== '' && Number.isFinite(n) && n >= 0 && n <= 1e20) ? n : null;
}
function parsePlaceId(raw) {
  const n = Number(raw);
  return Number.isSafeInteger(n) && n > 0 ? n : null;
}
function validEgg(item) {
  if (!item || typeof item !== 'object' || Array.isArray(item)) return null;
  const eggId = cleanText(item.id, 90);
  if (!eggId) return null;
  const rawValue = item.valuePerSecond;
  const value = rawValue === undefined || rawValue === null ? null : cleanNumber(rawValue);
  return {
    id: eggId,
    name: cleanText(item.name, 90) || 'Unidentified egg',
    rarity: cleanText(item.rarity, 45),
    area: cleanText(item.area, 65),
    mutation: cleanText(item.mutation, 50),
    valuePerSecond: value,
  };
}
export default {
  async fetch(request, env) {
    try {
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
      if (!env.DB) return json({ok:false, error:'D1 binding DB belum dikonfigurasi'}, 503);
      const url = new URL(request.url);
      if (request.method === 'GET' && url.pathname === '/health') {
        await env.DB.prepare('SELECT 1 AS ok').first();
        return json({ok:true, app:'SINNT EGG FINDER', version:1, ttlSeconds:TTL_SECONDS});
      }
      if (request.method === 'GET' && url.pathname === '/feed') {
        const placeId = parsePlaceId(url.searchParams.get('placeId'));
        if (!placeId) return json({ok:false,error:'placeId wajib dan harus valid'},400);
        const now = Math.floor(Date.now()/1000);
        const limit = Math.min(50, Math.max(1, Number(url.searchParams.get('limit')) || 25));
        const rarity = cleanText(url.searchParams.get('rarity'),45);
        const minValRaw = url.searchParams.get('minValue');
        const minVal = minValRaw === null ? null : cleanNumber(minValRaw);
        let sql = 'SELECT place_id,job_id,egg_id,egg_name,rarity,area,mutation,value_per_second,source,last_seen_at FROM sightings WHERE place_id=? AND last_seen_at>=?';
        const binds = [placeId, now-TTL_SECONDS];
        if (rarity && rarity.toLowerCase() !== 'all') { sql+=' AND LOWER(rarity)=LOWER(?)'; binds.push(rarity); }
        if (minVal !== null) { sql+=' AND value_per_second>=?'; binds.push(minVal); }
        sql+=' ORDER BY CASE WHEN value_per_second IS NULL THEN 1 ELSE 0 END, value_per_second DESC, last_seen_at DESC LIMIT ?';
        binds.push(Math.round(limit));
        const res = await env.DB.prepare(sql).bind(...binds).all();
        const eggs = (res.results||[]).map(row=>({
          placeId:row.place_id, jobId:row.job_id, id:row.egg_id,
          name:row.egg_name, rarity:row.rarity || null, area:row.area || null,
          mutation:row.mutation || null, valuePerSecond:row.value_per_second,
          source:row.source, ageSeconds:Math.max(0,now-row.last_seen_at)
        }));
        return json({ok:true,eggs, count:eggs.length, ttlSeconds:TTL_SECONDS, updatedAt:now});
      }
      if (request.method === 'POST' && url.pathname === '/report') {
        if (!env.REPORTER_KEY || String(env.REPORTER_KEY).length < 16) {
          return json({ok:false,error:'Secret REPORTER_KEY belum dikonfigurasi (min 16 karakter)'},503);
        }
        if (request.headers.get('Authorization') !== `Bearer ${env.REPORTER_KEY}`) {
          return json({ok:false,error:'Reporter key tidak valid'},401);
        }
        const raw = await request.text();
        if (raw.length > MAX_BODY_BYTES) return json({ok:false,error:'Payload terlalu besar'},413);
        let body;
        try { body=JSON.parse(raw); } catch (_) { return json({ok:false,error:'JSON tidak valid'},400); }
        const placeId = parsePlaceId(body.placeId);
        const jobId = cleanText(body.jobId,96);
        if (!placeId || !JOB_ID_RE.test(jobId) || !Array.isArray(body.eggs)) {
          return json({ok:false,error:'Butuh placeId, jobId dan array eggs'},400);
        }
        if (env.ALLOWED_PLACE_ID && String(env.ALLOWED_PLACE_ID) !== String(placeId)) {
          return json({ok:false,error:'PlaceId tidak diizinkan'},403);
        }
        if (body.eggs.length > MAX_EGGS_PER_REPORT) {
          return json({ok:false,error:'Maksimal 60 egg per laporan'},400);
        }
        const seen = new Map();
        for (const input of body.eggs) {
          const egg = validEgg(input);
          if (egg) seen.set(egg.id,egg);
        }
        const now = Math.floor(Date.now()/1000);
        if (seen.size) {
          const sql = `INSERT INTO sightings (id,place_id,job_id,egg_id,egg_name,rarity,area,mutation,value_per_second,source,last_seen_at)
            VALUES (?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET egg_name=excluded.egg_name,
            rarity=excluded.rarity,area=excluded.area,mutation=excluded.mutation,
            value_per_second=excluded.value_per_second,source=excluded.source,last_seen_at=excluded.last_seen_at`;
          const statements = [...seen.values()].map(e=>env.DB.prepare(sql).bind(
            `${placeId}:${jobId}:${e.id}`, placeId,jobId,e.id,e.name,e.rarity,e.area,e.mutation,e.valuePerSecond,'EggState',now));
          await env.DB.batch(statements);
        }
        return json({ok:true, accepted:seen.size, received:body.eggs.length, ttlSeconds:TTL_SECONDS});
      }
      return json({ok:false,error:'Endpoint tidak ditemukan. Gunakan /health, /feed, atau /report'},404);
    } catch (err) {
      console.error('SINNT Finder worker error', err && err.message);
      return json({ok:false,error:'Server error'},500);
    }
  },
  // Optional Cloudflare Cron Trigger: e.g. once each day to prune old rows.
  async scheduled(controller, env) {
    if (!env.DB) return;
    const oneDayAgo=Math.floor(Date.now()/1000)-86400;
    await env.DB.prepare('DELETE FROM sightings WHERE last_seen_at < ?').bind(oneDayAgo).run();
  }
};
