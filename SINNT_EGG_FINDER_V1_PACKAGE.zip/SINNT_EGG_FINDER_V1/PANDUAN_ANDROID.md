# SINNT EGG FINDER V1 — Panduan Android (Delta + Cloudflare)

**Penting:** ini bukan source Chilli Finder yang dibobol. Ini implementasi mandiri yang memakai `EggState.ReadFieldEggs().Records` bila game masih mengekspos modul tersebut. V1 hanya memantau **field eggs** yang datanya dapat dibaca dari client. Sistem pemantauan egg di pen/base pemain lain, perhitungan nilai /s dari data internal, dan skala pemantauan seperti layanan komersial **BELUM** tersedia. Tidak ada klaim bahwa scan, HTTP POST, atau JOIN sudah diuji di Roblox sungguhan.

## Isi paket

- `SINNT_FINDER_V1.lua`: client Delta Android. Scan lokal, feed online, filter, diagnostik, join, reporter opt-in.
- `worker.js`: backend Cloudflare Worker.
- `schema.sql`: struktur database D1.
- `test_worker.mjs`: tes backend dengan Node.js (opsional; sudah dijalankan penulis).
- `PANDUAN_ANDROID.md`: panduan ini.

## A. Persiapkan backend Cloudflare (dapat dilakukan lewat Chrome Android)

1. Buka https://dash.cloudflare.com/ dan login/buat akun.
2. Jika tombol sulit terlihat di HP, pada Chrome pilih menu titik tiga -> **Situs desktop**.
3. Masuk **Storage & databases -> D1 SQL Database** (posisi menu bisa berubah) -> **Create database**. Nama contoh: `sinnt-egg-finder`.
4. Buka database tersebut, bagian **Console**. Salin seluruh isi `schema.sql`, tempel dan jalankan sebagai SQL.
5. Masuk **Workers & Pages** -> **Create application** -> buat Worker sederhana (contoh nama: `sinnt-egg-finder`). Pilih template Hello World / Worker kosong bila tersedia.
6. Pada Worker pilih **Edit Code**. Ganti kode contoh dengan seluruh isi `worker.js`, lalu **Deploy**.
7. Di Worker, pilih **Bindings** -> **Add binding** -> **D1 database**. Nama binding **WAJIB `DB`** (huruf besar), pilih `sinnt-egg-finder`, lalu simpan/deploy.
8. Di Worker, buka **Settings** -> **Variables and Secrets** -> **Add**. Tipe **Secret**, nama **`REPORTER_KEY`**, value berupa kata sandi acak **minimal 16 karakter**. Contoh format: `S!nnT_2026_random_very_long` (JANGAN gunakan contoh ini untuk keamanan; buat sendiri). Deploy.
9. Opsional tapi dianjurkan: variabel teks `ALLOWED_PLACE_ID` sesuai `game.PlaceId` Steal an Egg. Jika belum yakin nilainya, kosongkan dulu. Nilai PlaceId yang terlihat pada loader Chilli publik adalah `107778070777162`, tapi verifikasi di dalam game.
10. Opsional: tambahkan **Cron Trigger** sekali per hari agar `scheduled()` menghapus record lama dari D1. Tanpa cron, data basi tidak ditampilkan di feed, tetapi tetap tersimpan di database.
11. Uji backend: kunjungi `https://NAMAWORKER.SUBDOMAIN.workers.dev/health` (gunakan alamat persis dari halaman Worker). Harus muncul `{"ok":true,...}`. Jika 503, binding database/secret belum benar.

**Jangan pernah menaruh Reporter Key di repository GitHub publik.** Key dibutuhkan oleh client yang kamu izinkan melaporkan Egg; siapa pun yang mendapat key dapat mengirim laporan palsu. Tidak ada keamanan anti-spoof sempurna untuk client executor.

## B. Pasang client di GitHub dan Delta (tanpa laptop)

1. Buka repository milikmu: https://github.com/itssinnt-byte/itssinnt-byte/upload/main
2. Unggah file `SINNT_FINDER_V1.lua` dari paket ini ke root branch `main`, lalu **Commit changes**.
3. Setelah ada di GitHub, pakai kode berikut di Delta (hanya berlaku jika nama file tepat):

```lua
loadstring(game:HttpGet("https://raw.githubusercontent.com/itssinnt-byte/itssinnt-byte/main/SINNT_FINDER_V1.lua"))()
```

4. Masuk ke game **Steal an Egg**, jalankan script di Delta.
5. Tekan **SCAN**. Menu harus menunjukkan data hasil pemindaian lokal atau menjelaskan jika modul `EggState` tidak ditemukan. Jika ada masalah, tekan **DIAG** dan salin hasilnya dari clipboard/console.
6. Tempel URL Worker yang berakhiran `.workers.dev` ke kotak pertama; tempel `REPORTER_KEY` ke kotak kedua, tekan **SAVE**. Hanya URL yang disimpan dalam file lokal; key hanya disimpan untuk sesi script saat ini.
7. Tekan **SCOUT: OFF** sehingga menjadi **SCOUT: ON**. Saat ON, client mengirim laporan EggState kira-kira tiap 22 detik.
8. Tekan **FEED** untuk melihat laporan dari server yang dipantau. Feed memperbarui sekitar 16 detik sekali.
9. Jalankan script yang sama pada **akun atau perangkat lain yang kamu miliki**, di server berbeda, dan aktifkan SCOUT di sana agar feed menampilkan temuan lintas server.
10. Tap baris Egg, lalu tekan **JOIN TARGET** untuk mencoba masuk ke server itu.

## C. Makna hasil dan batasan

- **Value `? /s`**: data income per detik tidak tersedia pada field yang diketahui. Script tidak mengarang nilai dari harga jual atau harga egg.
- **Egg #... / rarity unknown**: `EggState` memuat record tetapi namanya atau rarity belum dapat dipetakan dari struktur terbaru. Perlu diagnostik.
- **UNVERIFIED**: fallback tag `CarryAreaEgg`, hanya untuk scan lokal; TIDAK pernah dilaporkan ke feed.
- **Feed kosong**: belum ada reporter online pada server lain, EggState tidak menghasilkan record, server belum diatur, laporan telah kedaluwarsa (~100 detik), atau filter terlalu ketat.
- **Gagal POST**: Delta versi itu tidak menyediakan fungsi `request` yang kompatibel, key salah, atau backend belum siap.
- **Join gagal**: server penuh/tidak ada lagi, teleport dibatasi Roblox, atau data telah kedaluwarsa. `TeleportToPlaceInstance` adalah API lama/deprecated dan tidak menjamin keberhasilan join.
- **Scanner pen milik pemain lain**: tidak diimplementasikan; V1 membaca `EggState.ReadFieldEggs()` untuk field eggs, bukan klaim akses seluruh inventory/bases pemain lintas server.
- **Tidak melakukan Auto Steal / remote spamming / bypass anti-cheat.** Penggunaan executor tetap dapat melanggar aturan Roblox dan terkena sanksi akun.

## D. Apa yang sudah dites?

Pengujian backend lokal `node test_worker.mjs` lulus untuk endpoint health, autentikasi reporter, penambahan laporan, feed, filter rarity/nilai, expiry, dan validasi input. **Belum ada pengujian runtime Delta Android atau pemindaian EggState di game live.**

### Rujukan struktur

- Source terbuka yang memuat `EggState.ReadFieldEggs().Records`: https://github.com/Lutosys/opensrc/blob/main/StealAnEggAutofarm.lua
- Panduan Cloudflare D1: https://developers.cloudflare.com/d1/get-started/
- Binding D1 melalui dashboard: https://developers.cloudflare.com/d1/best-practices/remote-development/
- Roblox TeleportService: https://create.roblox.com/docs/reference/engine/classes/TeleportService
