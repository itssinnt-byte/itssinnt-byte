import { readFileSync } from 'node:fs';
import { DatabaseSync } from 'node:sqlite';
import assert from 'node:assert/strict';
import worker from './worker.js';
const db = new DatabaseSync(':memory:');
db.exec(readFileSync(new URL('./schema.sql', import.meta.url),'utf8'));
const adapt = {
  prepare(sql) {
    return {
      bind(...params) {
        const stmt=db.prepare(sql);
        return {
          async all() { return {results:stmt.all(...params)}; },
          async first() { return stmt.get(...params); },
          async run() { stmt.run(...params);return {success:true}; }
        };
      },
      async first() { return db.prepare(sql).get(); }
    };
  },
  async batch(queries) { const res=[];for (const q of queries) res.push(await q.run());return res; }
};
const env={DB:adapt, REPORTER_KEY:'a_secret_that_is_over_sixteen', ALLOWED_PLACE_ID:'107778070777162'};
const base='https://sinnt-demo.workers.dev';
async function request(path,method='GET',body, key) {
  const opts={method,headers:{'Content-Type':'application/json'}};
  if (key) opts.headers.Authorization='Bearer '+key;
  if (body) opts.body=JSON.stringify(body);
  const res=await worker.fetch(new Request(base+path,opts),env);
  return {status:res.status, data:await res.json()};
}
let h=await request('/health');assert.equal(h.status,200); assert.equal(h.data.ok,true);
const report={placeId:107778070777162,jobId:'123e4567-e89b-12d3-a456-426614174000',eggs:[
  {id:'egg-123',name:'Royal Skywhale',rarity:'Secret',area:'Cosmic',valuePerSecond:1750000000},
  {id:'egg-456',name:'Unknown egg',rarity:null,area:'Forest'}]};
assert.equal((await request('/report','POST',report,'bad-password')).status,401);
let result=await request('/report','POST',report,env.REPORTER_KEY);
assert.equal(result.status,200);assert.equal(result.data.accepted,2);
result=await request('/feed?placeId=107778070777162');
assert.equal(result.data.count,2);assert.equal(result.data.eggs[0].name,'Royal Skywhale');
assert.equal(result.data.eggs[0].valuePerSecond,1750000000);
assert.equal(result.data.eggs[1].valuePerSecond,null);
result=await request('/feed?placeId=107778070777162&rarity=Secret&minValue=2000000');assert.equal(result.data.count,1);
result=await request('/feed?placeId=107778070777162&rarity=Divine');assert.equal(result.data.count,0);
result=await request('/report','POST',{...report,placeId:1},env.REPORTER_KEY);assert.equal(result.status,403);
result=await request('/report','POST',{...report,eggs:Array(61).fill({id:'a'})},env.REPORTER_KEY);assert.equal(result.status,400);
db.prepare('UPDATE sightings SET last_seen_at=0').run();
result=await request('/feed?placeId=107778070777162');assert.equal(result.data.count,0);
console.log('PASS: health, auth, report, feed, sorting, null income, filters, allowed place, limit, stale expiry');
