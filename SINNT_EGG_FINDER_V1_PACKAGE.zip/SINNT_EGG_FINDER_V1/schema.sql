-- SINNT Egg Finder V1 / Cloudflare D1 (SQLite)
CREATE TABLE IF NOT EXISTS sightings (
  id TEXT PRIMARY KEY,
  place_id INTEGER NOT NULL,
  job_id TEXT NOT NULL,
  egg_id TEXT NOT NULL,
  egg_name TEXT NOT NULL,
  rarity TEXT,
  area TEXT,
  mutation TEXT,
  value_per_second REAL,
  source TEXT NOT NULL,
  last_seen_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sightings_recent ON sightings(place_id, last_seen_at DESC);
CREATE INDEX IF NOT EXISTS idx_sightings_value ON sightings(place_id, value_per_second DESC);
